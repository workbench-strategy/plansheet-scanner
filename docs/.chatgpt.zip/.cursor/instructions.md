# JV-1080 SYSEX FORMAT COMPLIANCE RULES - CORRECTED
# Cursor AI Configuration for JV-1080 Development

You are working on a JV-1080 synthesizer control system. CRITICAL: The JV-1080 uses BULK PATCH MESSAGES, not individual parameters. Follow these CORRECTED rules based on SOT documentation.

## 🚨 CRITICAL CORRECTION 🚨
**WRONG ASSUMPTION**: JV-1080 accepts individual parameter SYSEX messages  
**CORRECT FACT**: JV-1080 requires EXACTLY 5 bulk patch messages per complete patch

### JV-1080 BULK PATCH MESSAGE STRUCTURE (5 Messages Required)

```
Message 1 - Common Section:
F0 41 10 6A 12 03 00 00 [74 data bytes] [checksum] F7

Message 2 - Tone 1 Section:  
F0 41 10 6A 12 03 00 10 [131 data bytes] [checksum] F7

Message 3 - Tone 2 Section:
F0 41 10 6A 12 03 00 12 [131 data bytes] [checksum] F7

Message 4 - Tone 3 Section:
F0 41 10 6A 12 03 00 14 [131 data bytes] [checksum] F7

Message 5 - Tone 4 Section:
F0 41 10 6A 12 03 00 16 [131 data bytes] [checksum] F7

Header Breakdown:
F0 = SYSEX Start
41 = Roland Manufacturer ID  
10 = Device ID (0x10 default)
6A = JV-1080 Model ID
12 = DT1 Command (Data Set 1)
03 = Patch Mode identifier
00 XX = Section Address:
  - 00 = Common section (patch name, effects, etc.)
  - 10 = Tone 1 section
  - 12 = Tone 2 section  
  - 14 = Tone 3 section
  - 16 = Tone 4 section
[data] = Parameter data per Roland Tables 1-3-1 and 1-3-2
CC = Roland checksum
F7 = SYSEX End
```

### VERIFIED BULK PATCH ADDRESSES (FROM SOT)
```
Common Section:     03 00 00  (Roland Table 1-3-1, 74 bytes)
Tone 1 Section:     03 00 10  (Roland Table 1-3-2, 131 bytes)
Tone 2 Section:     03 00 12  (Roland Table 1-3-2, 131 bytes)  
Tone 3 Section:     03 00 14  (Roland Table 1-3-2, 131 bytes)
Tone 4 Section:     03 00 16  (Roland Table 1-3-2, 131 bytes)
```

### TONE SECTION DATA STRUCTURE (Table 1-3-2)
```
Byte Offset | Parameter
-----------|-----------
00         | Tone Switch (0=OFF, 1=ON)
01         | Wave Group (0=Internal, 1=Exp A, 2=Exp B)  
02         | Wave Group ID (0-127)
03         | Wave Number (0-254)
04         | (Reserved)
05         | Wave Gain (0-3)
06-130     | Additional parameters (envelope, filter, etc.)

Envelope parameters are embedded within these 131 bytes,
NOT sent as individual messages.
```

### ROLAND CHECKSUM ALGORITHM (MANDATORY)
```python
def calculate_roland_checksum(address_and_data_bytes):
    """
    Calculate Roland checksum for bulk patch data
    address_and_data_bytes = [0x03, 0x00, 0x10, ...data_bytes...]
    """
    checksum = 0
    for byte in address_and_data_bytes:
        checksum += byte
    
    checksum = (128 - (checksum % 128)) % 128
    return checksum
```

### REQUIRED BULK PATCH WORKFLOW

```python
# STEP 1: Import BULK patch systems (MANDATORY)
from working_sysex_generator import CorrectedJV1080SYSEXGenerator
from jv1080_sysex_validator import JV1080SysexValidator
from jv1080_sysex_preview_system import JV1080SysexPreviewSystem

# STEP 2: Create complete patch with 5 messages
generator = CorrectedJV1080SYSEXGenerator()
validator = JV1080SysexValidator()
preview_system = JV1080SysexPreviewSystem()

# STEP 3: Define patch parameters (embedded in bulk data)
patch_params = {
    'patch_name': 'TestPatch',
    'tone1_wave': 45,      # Embedded in Tone 1 message
    'tone1_attack': 64,    # Embedded in Tone 1 message  
    'tone1_decay': 80,     # Embedded in Tone 1 message
    'tone1_sustain': 100,  # Embedded in Tone 1 message
    'tone1_release': 90,   # Embedded in Tone 1 message
    'tone1_cutoff': 110    # Embedded in Tone 1 message
}

# STEP 4: Generate complete patch (5 messages)
patch = generator.create_patch_data(patch_params, "TestPatch")

# Create all 5 SYSEX messages
sysex_messages = [
    generator.create_sysex_message(patch.common_data, 'Common'),
    generator.create_sysex_message(patch.tone1_data, 'Tone 1'),  
    generator.create_sysex_message(patch.tone2_data, 'Tone 2'),
    generator.create_sysex_message(patch.tone3_data, 'Tone 3'),
    generator.create_sysex_message(patch.tone4_data, 'Tone 4')
]

# STEP 5: MANDATORY validation of all 5 messages
all_valid = True
for i, sysex in enumerate(sysex_messages):
    is_valid, errors = validator.validate_sysex_message(sysex)
    if not is_valid:
        print(f"🚨 Message {i+1} VALIDATION FAILED")
        for error in errors:
            print(f"   ERROR: {error.message}")
        all_valid = False

if not all_valid:
    print("🚨 BULK PATCH VALIDATION FAILED - ABORTING")
    return False

# STEP 6: MANDATORY bulk preview and confirmation
confirmed = preview_system.preview_bulk_patch(
    patch_params, sysex_messages, require_confirmation=True
)

if not confirmed:
    print("🚨 USER CANCELLED BULK TRANSMISSION")
    return False

# STEP 7: Send all 5 messages in sequence
for i, sysex in enumerate(sysex_messages):
    send_to_jv1080_hardware(sysex)
    print(f"Sent message {i+1}/5")
    time.sleep(0.05)  # 50ms delay between messages
```

### ABSOLUTELY PROHIBITED PRACTICES

- ❌ **NEVER** send individual parameter SYSEX to JV-1080  
- ❌ **NEVER** use addresses like 03 00 50, 03 00 51 (these don't exist for JV-1080)
- ❌ **NEVER** send single-byte parameter changes to JV-1080
- ❌ **NEVER** skip any of the 5 required patch messages
- ❌ **NEVER** send partial patches (must be complete 5-message set)
- ❌ **NEVER** bypass bulk message validation
- ❌ **NEVER** auto-confirm bulk patch transmissions

### CRITICAL ERROR CORRECTIONS

**OLD INCORRECT ASSUMPTIONS:**
```
❌ attack_time address = 03 00 50  (WRONG - doesn't exist)
❌ decay_time address = 03 00 51   (WRONG - doesn't exist)  
❌ Single parameter SYSEX messages (WRONG - not supported)
❌ 11-byte individual messages     (WRONG - JV-1080 uses bulk)
```

**NEW CORRECT IMPLEMENTATION:**
```
✅ Parameters embedded in Tone bulk messages
✅ 5 complete messages per patch (83 + 140 + 140 + 140 + 140 bytes)
✅ Use working_sysex_generator.py for proper structure
✅ Reference JV1080_SYSEX_PARAMETER_ADDRESSING_DISCOVERY.md
```

### SOT REFERENCE DOCUMENTS
- `JV1080_SYSEX_PARAMETER_ADDRESSING_DISCOVERY.md` - Verified 5-message structure
- `working_sysex_generator.py` - Correct bulk patch implementation  
- Roland JV1080.ini - Official parameter table definitions
- `databases/roland_jv1080_master.db` - Parameter database

**REMEMBER: JV-1080 is a BULK PATCH synthesizer, not individual parameter control.**
