"""
System Architect Agent Configuration (Google Gemini)

This agent specializes in designing scalable, maintainable software
architectures for complex audio processing and hardware control systems.
"""

AGENT_CONFIG = {
    "name": "System Architect",
    "version": "1.0", 
    "platform": "Google Gemini",
    "specialization": "Software Architecture for Audio/Hardware Systems"
}

ARCHITECTURAL_PRINCIPLES = [
    "Separation of concerns and modular design",
    "Loose coupling and high cohesion",
    "Scalability and performance optimization", 
    "Maintainability and code quality",
    "Hardware abstraction and device management",
    "Real-time processing requirements"
]

DESIGN_PATTERNS = {
    "creational": [
        "Factory Pattern for hardware device creation",
        "Builder Pattern for complex configuration objects",
        "Singleton Pattern for resource managers"
    ],
    
    "structural": [
        "Adapter Pattern for hardware interface compatibility",
        "Facade Pattern for simplified API design", 
        "Decorator Pattern for audio effect chaining"
    ],
    
    "behavioral": [
        "Observer Pattern for hardware state management",
        "Strategy Pattern for algorithm selection",
        "Command Pattern for MIDI message handling"
    ]
}

SYSTEM_ARCHITECTURE = {
    "layered_architecture": {
        "presentation": "GUI, CLI, and web interfaces",
        "application": "Business logic and workflow coordination",
        "domain": "Core audio/MIDI processing logic",
        "infrastructure": "Hardware communication and data persistence"
    },
    
    "microservices": {
        "hardware_service": "MIDI/SysEx communication management",
        "ml_service": "Machine learning inference engine",
        "audio_service": "Audio processing and analysis",
        "api_service": "REST API for external integration"
    },
    
    "event_driven": {
        "event_bus": "Central message routing system",
        "publishers": "Hardware state changes, user actions",
        "subscribers": "UI updates, data logging, automation"
    }
}

QUALITY_ATTRIBUTES = {
    "performance": {
        "metrics": ["Latency", "Throughput", "Resource usage"],
        "requirements": ["<10ms audio latency", ">100 MIDI msgs/sec", "<50% CPU usage"]
    },
    
    "reliability": {
        "metrics": ["Uptime", "Error rate", "Recovery time"],
        "requirements": ["99.9% uptime", "<0.1% error rate", "<5sec recovery"]
    },
    
    "scalability": {
        "metrics": ["Concurrent users", "Data volume", "Processing load"],
        "requirements": ["10+ concurrent users", "TB-scale data", "Real-time processing"]
    },
    
    "maintainability": {
        "metrics": ["Code complexity", "Test coverage", "Documentation"],
        "requirements": ["<10 cyclomatic complexity", ">90% coverage", "Complete API docs"]
    }
}

TECHNOLOGY_STACK = {
    "backend": [
        "Python 3.8+ for core development",
        "FastAPI for REST API services",
        "SQLAlchemy for data persistence", 
        "Redis for caching and session management"
    ],
    
    "frontend": [
        "Streamlit for rapid prototyping",
        "React for production web interfaces",
        "Electron for desktop applications"
    ],
    
    "infrastructure": [
        "Docker for containerization",
        "Kubernetes for orchestration",
        "PostgreSQL for structured data",
        "InfluxDB for time-series data"
    ]
}

PROMPT_TEMPLATE = """
You are the System Architect for Google Gemini. Your role is to design
robust, scalable software architectures for complex audio processing
and hardware control systems.

Key responsibilities:
- Design modular, maintainable system architectures
- Define component interfaces and communication protocols
- Ensure performance and scalability requirements are met
- Establish coding standards and quality practices
- Plan deployment and operational considerations

Focus on creating systems that can handle real-time audio processing,
complex hardware interactions, and machine learning workloads while
remaining maintainable and extensible.
"""

ARCHITECTURE_TEMPLATES = {
    "hardware_control_system": {
        "description": "Architecture for MIDI hardware control and automation",
        "components": [
            "Hardware abstraction layer",
            "MIDI communication manager", 
            "Device state management",
            "Command processing engine",
            "User interface layer"
        ]
    },
    
    "ml_inference_pipeline": {
        "description": "Real-time ML inference for audio processing",
        "components": [
            "Audio input processing",
            "Feature extraction pipeline",
            "Model inference engine", 
            "Output post-processing",
            "Performance monitoring"
        ]
    }
}