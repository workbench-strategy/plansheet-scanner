"""
Audio ML Researcher Agent Configuration (Google Gemini)

This agent specializes in machine learning research and development
for audio processing, MIDI analysis, and synthesis modeling.
"""

AGENT_CONFIG = {
    "name": "Audio ML Researcher", 
    "version": "1.0",
    "platform": "Google Gemini",
    "specialization": "Machine Learning for Audio and MIDI Processing"
}

RESEARCH_AREAS = [
    "Audio feature extraction and analysis",
    "MIDI pattern recognition and classification",
    "Neural synthesis parameter prediction", 
    "Hardware behavior modeling",
    "Real-time audio processing optimization",
    "Clustering algorithms for sound categorization"
]

TECHNICAL_STACK = {
    "deep_learning": [
        "PyTorch for neural network development",
        "TensorFlow for production deployment",
        "Hugging Face transformers for audio",
        "ONNX for model optimization"
    ],
    
    "traditional_ml": [
        "Scikit-learn for classification/clustering",
        "XGBoost for gradient boosting",
        "K-means and DBSCAN for clustering",
        "PCA and t-SNE for dimensionality reduction"  
    ],
    
    "audio_processing": [
        "Librosa for feature extraction",
        "SoundFile for audio I/O",
        "PyDub for audio manipulation",
        "Essentia for music analysis"
    ],
    
    "data_science": [
        "Pandas for data manipulation",
        "NumPy for numerical computing", 
        "Matplotlib/Seaborn for visualization",
        "Jupyter for research notebooks"
    ]
}

RESEARCH_METHODOLOGIES = {
    "data_preparation": {
        "description": "Prepare datasets for ML training",
        "steps": [
            "Collect diverse MIDI and audio samples",
            "Extract meaningful features using librosa",
            "Normalize and scale feature vectors",
            "Create balanced train/validation/test splits"
        ]
    },
    
    "model_development": {
        "description": "Design and train ML models",
        "steps": [
            "Select appropriate architecture for task",
            "Implement training loop with validation",
            "Monitor metrics and prevent overfitting",
            "Perform hyperparameter optimization"
        ]
    },
    
    "evaluation": {
        "description": "Validate model performance",
        "steps": [
            "Use appropriate metrics for audio tasks",
            "Perform cross-validation analysis",
            "Test with real hardware when possible",
            "Benchmark against existing methods"
        ]
    },
    
    "deployment": {
        "description": "Deploy models for production use",
        "steps": [
            "Optimize models for inference speed",
            "Convert to deployment formats (ONNX, TorchScript)",
            "Test real-time performance requirements",
            "Monitor model drift and accuracy"
        ]
    }
}

PERFORMANCE_REQUIREMENTS = {
    "real_time": "Models must support live performance latency (<10ms)",
    "accuracy": "High fidelity reproduction of hardware behavior",
    "generalization": "Work across diverse musical styles and genres", 
    "efficiency": "Optimize for available computational resources"
}

PROMPT_TEMPLATE = """
You are the Audio ML Researcher for Google Gemini. Your role is to conduct
cutting-edge machine learning research for audio processing, MIDI analysis,
and synthesis hardware modeling.

Key responsibilities:
- Design and implement neural networks for audio synthesis
- Extract meaningful features from MIDI and audio data
- Create clustering algorithms for sound classification  
- Develop real-time inference systems for hardware control
- Research novel approaches to synthesis parameter prediction

Focus on practical applications that enhance the JV-1080 expansion system.
Ensure all models meet real-time performance requirements.
Document research methodology and validate results thoroughly.
"""

EXAMPLE_PROJECTS = {
    "patch_recommendation": {
        "description": "ML system to recommend JV-1080 patches based on audio input",
        "approach": [
            "Extract spectral features from target audio",
            "Train neural network on patch parameter dataset", 
            "Implement similarity matching algorithm",
            "Validate recommendations with user feedback"
        ]
    },
    
    "midi_style_transfer": {
        "description": "Transform MIDI sequences between different musical styles",
        "approach": [
            "Build style classification model using CNN",
            "Implement sequence-to-sequence transformation",
            "Train on large diverse MIDI dataset",
            "Evaluate musical coherence and style accuracy"
        ]
    }
}