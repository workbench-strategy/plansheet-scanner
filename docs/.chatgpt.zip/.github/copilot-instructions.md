# JV-1080 SYSEX FORMAT COMPLIANCE RULES
# GitHub Copilot Configuration for JV-1080 Development

## CRITICAL SYSEX VALIDATION RULES - CORRECTED BASED ON SOT

### Rule 1: JV-1080 uses BULK PATCH MESSAGES, not individual parameters
- A complete JV-1080 patch consists of EXACTLY 5 SYSEX messages
- NEVER send individual parameter messages to JV-1080
- ALWAYS send complete patch messages in the correct sequence

### Rule 2: MANDATORY 5-MESSAGE STRUCTURE for JV-1080 Patches
```
Message 1 - Common:  F0 41 10 6A 12 03 00 00 [74 data bytes] [checksum] F7
Message 2 - Tone 1:  F0 41 10 6A 12 03 00 10 [131 data bytes] [checksum] F7  
Message 3 - Tone 2:  F0 41 10 6A 12 03 00 12 [131 data bytes] [checksum] F7
Message 4 - Tone 3:  F0 41 10 6A 12 03 00 14 [131 data bytes] [checksum] F7
Message 5 - Tone 4:  F0 41 10 6A 12 03 00 16 [131 data bytes] [checksum] F7

F0    = SYSEX Start (0xF0)
41    = Manufacturer ID (Roland)
10    = Device ID (0x10 default)
6A    = Model ID (JV-1080)
12    = Command ID (DT1 - Data Set)
03    = Patch Mode identifier
00 XX = Address (00=Common, 10=Tone1, 12=Tone2, 14=Tone3, 16=Tone4)
[data]= Parameter data based on Roland Table 1-3-1 (Common) or 1-3-2 (Tones)
CC    = Checksum
F7    = SYSEX End (0xF7)
```

### Rule 3: CORRECT JV-1080 Bulk Patch Addresses (FROM SOT)
```
Common Section:     03 00 00  (Table 1-3-1, 74 data bytes)
Tone 1 Section:     03 00 10  (Table 1-3-2, 131 data bytes)
Tone 2 Section:     03 00 12  (Table 1-3-2, 131 data bytes)
Tone 3 Section:     03 00 14  (Table 1-3-2, 131 data bytes)
Tone 4 Section:     03 00 16  (Table 1-3-2, 131 data bytes)
```

### Rule 4: Tone Parameter Structure (Table 1-3-2)
```
Offset 00: Tone Switch (0=OFF, 1=ON)
Offset 01: Wave Group (0=Internal, 1=Expansion A, 2=Expansion B)
Offset 02: Wave Group ID (0-127)
Offset 03: Wave Number (0-254)
Offset 04: (Reserved)
Offset 05: Wave Gain (0-3)
Offset 06-130: Additional tone parameters (envelope, filter, etc.)
```

### Rule 5: WRONG - Individual Parameter Addressing 
```
❌ INCORRECT: attack_time = 03 00 50
❌ INCORRECT: decay_time = 03 00 51  
❌ INCORRECT: Single parameter SYSEX messages

✅ CORRECT: Parameters are embedded within Tone bulk messages
✅ CORRECT: Use complete 5-message patch structure
✅ CORRECT: Reference Roland Table 1-3-2 for parameter positions
```

### Rule 6: Checksum Calculation (MANDATORY)
```python
def calculate_roland_checksum(data_bytes):
    checksum = 0
    for byte in data_bytes:  # Address + Data bytes only
        checksum += byte
    checksum = (128 - (checksum % 128)) % 128
    return checksum
```

### Rule 7: Bulk Message Validation
- ALWAYS validate all 5 messages before transmission
- REQUIRE explicit user confirmation for complete patch
- NEVER auto-send bulk patches without user approval
- Show preview of all 5 messages

### Rule 8: Error Handling
- ABORT transmission if any of the 5 messages fail validation
- Log all bulk SYSEX activity for debugging
- Provide clear error messages with expected vs actual values

### Rule 9: Safety Classifications
```
SAFE:     Complete patch with validated structure
CAUTION:  Modified wave numbers or levels
WARNING:  Custom parameter combinations
CRITICAL: Any malformed bulk message structure
```

### Rule 10: SOT Document Reference
- ALWAYS reference JV1080_SYSEX_PARAMETER_ADDRESSING_DISCOVERY.md
- Use verified 5-message patch structure from SOT
- Follow Roland Table 1-3-1 and Table 1-3-2 exactly

## PROHIBITED PRACTICES
- ❌ NEVER send individual parameter SYSEX to JV-1080
- ❌ NEVER use addresses like 03 00 50, 03 00 51 for JV-1080
- ❌ NEVER skip any of the 5 required messages
- ❌ NEVER ignore bulk message sequence requirements
- ❌ NEVER auto-confirm bulk patch operations

## REQUIRED IMPORTS
```python
from working_sysex_generator import CorrectedJV1080SYSEXGenerator
from jv1080_sysex_validator import JV1080SysexValidator
from jv1080_sysex_preview_system import JV1080SysexPreviewSystem
```

## EXAMPLE COMPLIANT CODE
```python
# Create bulk patch generator
generator = CorrectedJV1080SYSEXGenerator()
validator = JV1080SysexValidator()
preview_system = JV1080SysexPreviewSystem()

# Create complete 5-message patch
patch_params = {
    'attack_time': 64,
    'decay_time': 80,
    'sustain_level': 100,
    'release_time': 90,
    'filter_cutoff': 110
}

patch = generator.create_patch_data(patch_params, "TestPatch")

# Generate all 5 SYSEX messages
sysex_messages = [
    generator.create_complete_sysex(patch.common_data, 'Common'),
    generator.create_complete_sysex(patch.tone1_data, 'Tone 1'),
    generator.create_complete_sysex(patch.tone2_data, 'Tone 2'),
    generator.create_complete_sysex(patch.tone3_data, 'Tone 3'),
    generator.create_complete_sysex(patch.tone4_data, 'Tone 4')
]

# Validate all 5 messages
for i, sysex in enumerate(sysex_messages):
    is_valid, errors = validator.validate_sysex_message(sysex)
    if not is_valid:
        print(f"Message {i+1} validation failed!")
        return False

# Show bulk preview and get confirmation
confirmed = preview_system.preview_bulk_patch(
    patch_params, sysex_messages, require_confirmation=True
)
if not confirmed:
    print("User cancelled bulk patch transmission")
    return False

# Send all 5 messages in sequence
for sysex in sysex_messages:
    send_to_hardware(sysex)
    time.sleep(0.05)  # 50ms delay between messages
```

## VALIDATION CHECKLIST
- [ ] Using complete 5-message patch structure
- [ ] All messages follow F0 41 10 6A 12 03 00 XX format
- [ ] Common message uses address 03 00 00
- [ ] Tone messages use addresses 03 00 10, 12, 14, 16
- [ ] All data follows Roland Table specifications
- [ ] Checksums are correctly calculated
- [ ] User has confirmed bulk transmission
- [ ] All 5 messages validated before sending
