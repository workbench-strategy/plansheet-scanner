# JV-1080 SYSEX FORMAT COMPLIANCE RULES - CORRECTED
# Claude AI Configuration for JV-1080 Development

## SYSTEM DIRECTIVE: JV-1080 HARDWARE PROTECTION - CORRECTED BASED ON SOT

You are an AI assistant working on a Roland JV-1080 synthesizer control system. 

**🚨 CRITICAL CORRECTION 🚨**
**PREVIOUS ERROR**: Assumed JV-1080 accepts individual parameter SYSEX messages  
**CORRECT FACT**: JV-1080 requires EXACTLY 5 bulk patch messages per complete patch

### 🚨 ABSOLUTE SAFETY REQUIREMENTS 🚨

1. **NEVER GENERATE INDIVIDUAL PARAMETER SYSEX FOR JV-1080**
2. **ALWAYS USE BULK PATCH MESSAGES (5 messages total)**
3. **REQUIRE EXPLICIT USER CONFIRMATION BEFORE BULK TRANSMISSION**
4. **ABORT ON ANY BULK MESSAGE VALIDATION ERRORS**
5. **REFERENCE SOT DOCUMENTATION FOR ALL IMPLEMENTATIONS**

### MANDATORY JV-1080 BULK PATCH STRUCTURE

Every JV-1080 patch MUST consist of exactly 5 SYSEX messages:

```
Message 1 - Common Section (83 bytes total):
F0 41 10 6A 12 03 00 00 [74 data bytes] [checksum] F7

Message 2 - Tone 1 Section (140 bytes total):
F0 41 10 6A 12 03 00 10 [131 data bytes] [checksum] F7

Message 3 - Tone 2 Section (140 bytes total):
F0 41 10 6A 12 03 00 12 [131 data bytes] [checksum] F7

Message 4 - Tone 3 Section (140 bytes total):
F0 41 10 6A 12 03 00 14 [131 data bytes] [checksum] F7

Message 5 - Tone 4 Section (140 bytes total):
F0 41 10 6A 12 03 00 16 [131 data bytes] [checksum] F7

Header Structure:
F0 = SYSEX Start Byte (0xF0) - MANDATORY
41 = Roland Manufacturer ID (0x41) - MANDATORY  
10 = Device ID (0x10 default)
6A = JV-1080 Model ID (0x6A) - MANDATORY
12 = DT1 Command ID (0x12 = Data Set 1)
03 = Patch Mode identifier
00 XX = Section address:
  - 00 = Common section (patch name, effects)
  - 10 = Tone 1 section
  - 12 = Tone 2 section
  - 14 = Tone 3 section  
  - 16 = Tone 4 section
[data] = Parameter data per Roland Tables 1-3-1 and 1-3-2
CC = Roland Checksum - MANDATORY
F7 = SYSEX End Byte (0xF7) - MANDATORY
```

### VERIFIED BULK PATCH ADDRESSES (FROM SOT)

Only use these VERIFIED bulk addresses from SOT documentation:

```
Common Section:     03 00 00  (Roland Table 1-3-1, 74 data bytes)
Tone 1 Section:     03 00 10  (Roland Table 1-3-2, 131 data bytes)
Tone 2 Section:     03 00 12  (Roland Table 1-3-2, 131 data bytes)
Tone 3 Section:     03 00 14  (Roland Table 1-3-2, 131 data bytes)
Tone 4 Section:     03 00 16  (Roland Table 1-3-2, 131 data bytes)

Parameters like attack/decay/sustain/release are EMBEDDED within
the 131-byte Tone section data, NOT sent as individual messages.
```

### TONE SECTION PARAMETER STRUCTURE (Table 1-3-2)

```
Byte Offset | Parameter | Range | Description
------------|-----------|-------|------------
00          | Tone Switch | 0-1 | 0=OFF, 1=ON
01          | Wave Group | 0-2 | 0=Internal, 1=Exp A, 2=Exp B
02          | Wave Group ID | 0-127 | Wave group identifier
03          | Wave Number | 0-254 | Waveform number
04          | (Reserved) | - | Reserved byte
05          | Wave Gain | 0-3 | Wave amplification
06-50       | TVF Parameters | - | Filter settings (cutoff embedded here)
51-80       | TVA Parameters | - | Amplifier/Envelope (attack/decay/sustain/release embedded here)
81-130      | Other Parameters | - | LFO, pitch, etc.

CRITICAL: Individual parameters like attack_time, decay_time are
embedded within these 131 bytes, NOT addressable individually.
```

### ROLAND CHECKSUM CALCULATION (CRITICAL)

ALWAYS use this exact algorithm for bulk messages:

```python
def calculate_roland_checksum(data_bytes):
    """
    Calculate Roland checksum for bulk patch data
    data_bytes = [address_high, address_mid, address_low, ...data...]
    """
    checksum = 0
    for byte in data_bytes:
        checksum += byte
    
    # Roland checksum formula
    checksum = (128 - (checksum % 128)) % 128
    return checksum

# Example: Common section address 03 00 00 with 74 data bytes
# data_bytes = [0x03, 0x00, 0x00, ...74_data_bytes...]
# Calculate checksum for entire data portion
```

### REQUIRED BULK PATCH WORKFLOW

EVERY JV-1080 operation MUST follow this exact pattern:

```python
# STEP 1: Import BULK patch systems (MANDATORY)
from working_sysex_generator import CorrectedJV1080SYSEXGenerator
from jv1080_sysex_validator import JV1080SysexValidator
from jv1080_sysex_preview_system import JV1080SysexPreviewSystem

# STEP 2: Initialize bulk patch systems (MANDATORY)
generator = CorrectedJV1080SYSEXGenerator()
validator = JV1080SysexValidator()
preview_system = JV1080SysexPreviewSystem()

# STEP 3: Create complete patch with embedded parameters
def create_jv1080_bulk_patch(patch_params):
    # Parameters are embedded in bulk messages, not individual
    patch_data = {
        'patch_name': patch_params.get('name', 'TestPatch'),
        'tone1_attack': patch_params.get('attack_time', 64),    # Embedded in Tone 1
        'tone1_decay': patch_params.get('decay_time', 80),     # Embedded in Tone 1
        'tone1_sustain': patch_params.get('sustain_level', 100), # Embedded in Tone 1
        'tone1_release': patch_params.get('release_time', 90),  # Embedded in Tone 1
        'tone1_cutoff': patch_params.get('filter_cutoff', 110)  # Embedded in Tone 1
    }
    
    # Generate complete patch structure (5 messages)
    patch = generator.create_patch_data(patch_data, patch_data['patch_name'])
    
    # Create all 5 SYSEX messages
    sysex_messages = [
        generator.create_complete_sysex(patch.common_data, 'Common'),
        generator.create_complete_sysex(patch.tone1_data, 'Tone 1'),
        generator.create_complete_sysex(patch.tone2_data, 'Tone 2'),
        generator.create_complete_sysex(patch.tone3_data, 'Tone 3'),
        generator.create_complete_sysex(patch.tone4_data, 'Tone 4')
    ]
    
    return sysex_messages

# STEP 4: MANDATORY validation of all 5 messages
sysex_messages = create_jv1080_bulk_patch(user_params)

all_valid = True
for i, sysex in enumerate(sysex_messages):
    is_valid, errors = validator.validate_sysex_message(sysex)
    if not is_valid:
        print(f"🚨 Bulk Message {i+1} VALIDATION FAILED")
        for error in errors:
            print(f"   ERROR: {error.message}")
        all_valid = False

if not all_valid:
    print("🚨 BULK PATCH VALIDATION FAILED - ABORTING")
    return False

# STEP 5: MANDATORY bulk preview and user confirmation
confirmed = preview_system.preview_bulk_patch(
    user_params, sysex_messages, require_confirmation=True
)

if not confirmed:
    print("🚨 USER CANCELLED BULK PATCH TRANSMISSION")
    return False

# STEP 6: Send all 5 messages sequentially with delays
for i, sysex in enumerate(sysex_messages):
    send_to_jv1080_hardware(sysex)
    print(f"Sent bulk message {i+1}/5")
    time.sleep(0.05)  # 50ms delay between bulk messages
```

### CRITICAL ERROR CORRECTIONS

**PREVIOUS INCORRECT ASSUMPTIONS (NOW PROHIBITED):**
```
❌ WRONG: attack_time address = 03 00 50 (doesn't exist for JV-1080)
❌ WRONG: decay_time address = 03 00 51 (doesn't exist for JV-1080)
❌ WRONG: Individual parameter SYSEX messages (not supported by JV-1080)
❌ WRONG: 11-byte single parameter messages (JV-1080 uses bulk only)
❌ WRONG: Sending one parameter at a time (must send complete 5-message patch)
```

**CORRECT IMPLEMENTATION (MANDATORY):**
```
✅ CORRECT: Parameters embedded within bulk Tone messages
✅ CORRECT: Always send complete 5-message patches (643 bytes total)
✅ CORRECT: Use working_sysex_generator.py for proper bulk structure
✅ CORRECT: Reference JV1080_SYSEX_PARAMETER_ADDRESSING_DISCOVERY.md
✅ CORRECT: Validate all 5 messages before transmission
✅ CORRECT: Require user confirmation for bulk operations
```

### ABSOLUTELY PROHIBITED PRACTICES

- ❌ **NEVER** generate individual parameter SYSEX for JV-1080
- ❌ **NEVER** use addresses like 03 00 50, 03 00 51 (these don't exist for JV-1080)
- ❌ **NEVER** send single parameter changes to JV-1080
- ❌ **NEVER** skip any of the 5 required bulk messages
- ❌ **NEVER** send partial patches (must be complete 5-message set)
- ❌ **NEVER** bypass bulk patch validation
- ❌ **NEVER** auto-confirm bulk patch transmissions

### SAFETY CLASSIFICATION SYSTEM

ALWAYS classify bulk operations by safety level:

```
✅ SAFE:     Complete patch with validated 5-message structure
⚠️  CAUTION: Modified wave numbers or high levels in bulk data
🚨 WARNING: Custom parameter combinations in bulk patch
🛑 CRITICAL: Any malformed bulk message structure
```

### ERROR HANDLING REQUIREMENTS

```python
# ALWAYS handle bulk validation failures
try:
    for i, sysex in enumerate(sysex_messages):
        is_valid, errors = validator.validate_sysex_message(sysex)
        if not is_valid:
            log_bulk_validation_failure(i+1, sysex, errors)
            notify_user_of_bulk_errors(i+1, errors)
            return False  # ABORT entire bulk transmission
            
except Exception as e:
    log_critical_error(f"Bulk patch system failure: {e}")
    return False  # ABORT on any exception

# ALWAYS respect user cancellation of bulk operations
if not user_confirmed_bulk_transmission:
    log_user_bulk_cancellation(sysex_messages)
    return False  # ABORT if user says no to bulk patch
```

### DOCUMENTATION REFERENCES

Always reference these SOT documents:
- `JV1080_SYSEX_PARAMETER_ADDRESSING_DISCOVERY.md` - Verified 5-message structure
- `working_sysex_generator.py` - Correct bulk patch implementation
- `databases/roland_jv1080_master.db` - Parameter database
- `jv1080_sysex_validator.py` - Bulk validation rules
- `jv1080_sysex_preview_system.py` - Bulk safety preview system

### VALIDATION CHECKLIST

Before suggesting ANY JV-1080 SYSEX code, verify:

- [ ] Using complete 5-message bulk patch structure
- [ ] All messages follow F0 41 10 6A 12 03 00 XX format
- [ ] Common message uses address 03 00 00 (74 data bytes)
- [ ] Tone messages use addresses 03 00 10, 12, 14, 16 (131 data bytes each)
- [ ] Parameters are embedded within bulk data, not individual messages
- [ ] All bulk data follows Roland Table specifications
- [ ] Checksums are correctly calculated for each bulk message
- [ ] Bulk validation system is used
- [ ] User confirmation is required for bulk operations
- [ ] Error handling is implemented for bulk failures

**REMEMBER: JV-1080 is a BULK PATCH synthesizer. Individual parameter control does not exist. Hardware protection is the TOP PRIORITY.**
